This project is to analyze the Chicago crime data and make predictions of crime category.
The data and shapefile are imported from the Chicago Data Portal website.
The packages mainly used in this project are: Pandas, Numpy, Seaborn, Matplotlib, Sklearn, Xgboost.
